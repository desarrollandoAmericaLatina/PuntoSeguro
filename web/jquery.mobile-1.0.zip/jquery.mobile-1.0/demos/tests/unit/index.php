<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
	<link rel="stylesheet" href="../../external/qunit.css" />
	<script src="../../jquery.js"></script>
	<script src="../../external/qunit.js"></script>
	<script src="runner.js"></script>
  <style type="text/css">
    html, body {
      width:100%;
      height:100%;
      margin:0px;
      padding:0px;
    }

    #testFrame {
      float: left;
      border: 0px;
      height: 100%;
      width: 60%;
    }

    #results {
      float: left;
      width: 30%;
    }
  </style>
</head>
<body>
  <div id="results">
    <h1 id="qunit-header"><a href="#">jQuery Mobile Test Suite</a></h1>
    <h2 id="qunit-banner"></h2>
    <ol id="qunit-tests">
    </ol>
  </div>
	<iframe data-src="../../tests/unit/{{testdir}}" name="testFrame" id="testFrame" scrolling="no">
	</iframe>
</body>
</html>
